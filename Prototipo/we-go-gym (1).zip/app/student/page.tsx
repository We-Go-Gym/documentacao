import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { WorkoutCard } from "@/components/workout-card"
import { Badge } from "@/components/ui/badge"
import { Calendar, TrendingUp, Target, Award } from "lucide-react"

// Mock data
const mockWorkouts = [
  {
    id: "1",
    name: "Treino de Peito e Tríceps",
    description: "Foco no desenvolvimento da musculatura do peito e tríceps com exercícios compostos e isolados.",
    duration: 60,
    difficulty: "Intermediário" as const,
    exercises: 8,
    category: "Hipertrofia",
  },
  {
    id: "2",
    name: "Cardio HIIT",
    description: "Treino intervalado de alta intensidade para queima de gordura e condicionamento.",
    duration: 30,
    difficulty: "Avançado" as const,
    exercises: 6,
    category: "Cardio",
  },
  {
    id: "3",
    name: "Treino de Pernas",
    description: "Desenvolvimento completo dos membros inferiores com foco em força e resistência.",
    duration: 75,
    difficulty: "Intermediário" as const,
    exercises: 10,
    category: "Força",
  },
]

const mockStats = {
  workoutsThisWeek: 4,
  totalWorkouts: 28,
  currentStreak: 7,
  nextWorkout: "Treino de Costas e Bíceps",
}

export default function StudentDashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Olá, João!</h1>
        <p className="text-muted-foreground">Bem-vindo de volta. Vamos continuar sua jornada fitness!</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Treinos esta semana</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.workoutsThisWeek}</div>
            <p className="text-xs text-muted-foreground">+2 desde a semana passada</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de treinos</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalWorkouts}</div>
            <p className="text-xs text-muted-foreground">Desde o início</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sequência atual</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.currentStreak}</div>
            <p className="text-xs text-muted-foreground">dias consecutivos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Próximo treino</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-bold">{mockStats.nextWorkout}</div>
            <p className="text-xs text-muted-foreground">Agendado para hoje</p>
          </CardContent>
        </Card>
      </div>

      {/* Current Workouts */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Seus Treinos</h2>
          <Badge variant="secondary">{mockWorkouts.length} treinos ativos</Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockWorkouts.map((workout) => (
            <WorkoutCard key={workout.id} workout={workout} />
          ))}
        </div>
      </div>
    </div>
  )
}
