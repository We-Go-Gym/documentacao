import { BMICalculator } from "@/components/bmi-calculator"
import { WeightProgressChart } from "@/components/weight-progress-chart"
import { BMIProgressChart } from "@/components/bmi-progress-chart"
import { WeightTracker } from "@/components/weight-tracker"

export default function ProgressPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">IMC & Progresso</h1>
        <p className="text-muted-foreground">
          Acompanhe sua evolução física e monitore seu progresso ao longo do tempo.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column */}
        <div className="space-y-8">
          <BMICalculator />
          <WeightTracker />
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          <WeightProgressChart />
          <BMIProgressChart />
        </div>
      </div>
    </div>
  )
}
