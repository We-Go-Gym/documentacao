import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Clock, Target, Zap, Play, ArrowLeft } from "lucide-react"
import Link from "next/link"

// Mock workout data with exercises
const mockWorkoutDetails = {
  id: "1",
  name: "Treino de Peito e Tríceps",
  description: "Foco no desenvolvimento da musculatura do peito e tríceps com exercícios compostos e isolados.",
  duration: 60,
  difficulty: "Intermediário",
  category: "Hipertrofia",
  exercises: [
    {
      id: "1",
      name: "Supino Reto com Barra",
      sets: 4,
      reps: "8-10",
      rest: "2-3 min",
      description:
        "Exercício composto para desenvolvimento do peitoral maior. Mantenha os pés firmes no chão e controle o movimento.",
      tips: "Desça a barra até tocar o peito e empurre com força controlada.",
    },
    {
      id: "2",
      name: "Supino Inclinado com Halteres",
      sets: 3,
      reps: "10-12",
      rest: "90s",
      description: "Foco na porção superior do peitoral. Use banco inclinado a 30-45 graus.",
      tips: "Mantenha os cotovelos ligeiramente flexionados durante todo o movimento.",
    },
    {
      id: "3",
      name: "Crucifixo Reto",
      sets: 3,
      reps: "12-15",
      rest: "60s",
      description: "Exercício de isolamento para o peitoral. Movimento de abertura e fechamento.",
      tips: "Sinta o alongamento no peitoral na descida e contraia na subida.",
    },
    {
      id: "4",
      name: "Paralelas",
      sets: 3,
      reps: "8-12",
      rest: "2 min",
      description: "Exercício composto que trabalha peito inferior e tríceps.",
      tips: "Incline o tronco para frente para focar mais no peito.",
    },
    {
      id: "5",
      name: "Tríceps Testa",
      sets: 3,
      reps: "10-12",
      rest: "90s",
      description: "Isolamento do tríceps. Movimento apenas do antebraço.",
      tips: "Mantenha os cotovelos fixos e controle a descida.",
    },
    {
      id: "6",
      name: "Tríceps Corda",
      sets: 3,
      reps: "12-15",
      rest: "60s",
      description: "Exercício no cabo para finalizar o tríceps.",
      tips: "Abra a corda no final do movimento para máxima contração.",
    },
  ],
}

export default function WorkoutDetailsPage({ params }: { params: { id: string } }) {
  const workout = mockWorkoutDetails

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Iniciante":
        return "bg-green-100 text-green-800"
      case "Intermediário":
        return "bg-yellow-100 text-yellow-800"
      case "Avançado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" asChild>
          <Link href="/student/workouts">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Link>
        </Button>
      </div>

      {/* Workout Info */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl mb-2">{workout.name}</CardTitle>
              <CardDescription className="text-base">{workout.description}</CardDescription>
            </div>
            <Badge className={getDifficultyColor(workout.difficulty)}>{workout.difficulty}</Badge>
          </div>
          <div className="flex items-center space-x-6 text-sm text-muted-foreground mt-4">
            <div className="flex items-center">
              <Clock className="mr-2 h-4 w-4" />
              {workout.duration} minutos
            </div>
            <div className="flex items-center">
              <Target className="mr-2 h-4 w-4" />
              {workout.exercises.length} exercícios
            </div>
            <div className="flex items-center">
              <Zap className="mr-2 h-4 w-4" />
              {workout.category}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Button size="lg" className="w-full sm:w-auto">
            <Play className="mr-2 h-4 w-4" />
            Iniciar Treino
          </Button>
        </CardContent>
      </Card>

      {/* Exercises */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Exercícios</h2>
        <div className="space-y-4">
          {workout.exercises.map((exercise, index) => (
            <Card key={exercise.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      {index + 1}. {exercise.name}
                    </CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-2">
                      <span>{exercise.sets} séries</span>
                      <span>{exercise.reps} repetições</span>
                      <span>Descanso: {exercise.rest}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-3">{exercise.description}</p>
                <Separator className="my-3" />
                <div className="bg-accent/10 p-3 rounded-lg">
                  <p className="text-sm font-medium text-accent-foreground">💡 Dica:</p>
                  <p className="text-sm text-muted-foreground mt-1">{exercise.tips}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
