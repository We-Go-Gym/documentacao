import { WorkoutCard } from "@/components/workout-card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search } from "lucide-react"

// Mock data - expanded workout list
const mockWorkouts = [
  {
    id: "1",
    name: "Treino de Peito e Tríceps",
    description: "Foco no desenvolvimento da musculatura do peito e tríceps com exercícios compostos e isolados.",
    duration: 60,
    difficulty: "Intermediário" as const,
    exercises: 8,
    category: "Hipertrofia",
  },
  {
    id: "2",
    name: "Cardio HIIT",
    description: "Treino intervalado de alta intensidade para queima de gordura e condicionamento.",
    duration: 30,
    difficulty: "Avançado" as const,
    exercises: 6,
    category: "Cardio",
  },
  {
    id: "3",
    name: "Treino de Pernas",
    description: "Desenvolvimento completo dos membros inferiores com foco em força e resistência.",
    duration: 75,
    difficulty: "Intermediário" as const,
    exercises: 10,
    category: "Força",
  },
  {
    id: "4",
    name: "Treino de Costas e Bíceps",
    description: "Fortalecimento das costas e desenvolvimento dos bíceps com movimentos de puxada.",
    duration: 65,
    difficulty: "Intermediário" as const,
    exercises: 9,
    category: "Hipertrofia",
  },
  {
    id: "5",
    name: "Treino Funcional",
    description: "Exercícios funcionais para melhorar mobilidade, estabilidade e coordenação.",
    duration: 45,
    difficulty: "Iniciante" as const,
    exercises: 7,
    category: "Funcional",
  },
  {
    id: "6",
    name: "Treino de Ombros",
    description: "Desenvolvimento completo dos deltoides com exercícios específicos para ombros.",
    duration: 50,
    difficulty: "Avançado" as const,
    exercises: 8,
    category: "Hipertrofia",
  },
]

export default function WorkoutsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Meus Treinos</h1>
        <p className="text-muted-foreground">Todos os seus treinos organizados em um só lugar.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input placeholder="Buscar treinos..." className="pl-10" />
        </div>
        <Select>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            <SelectItem value="hipertrofia">Hipertrofia</SelectItem>
            <SelectItem value="cardio">Cardio</SelectItem>
            <SelectItem value="forca">Força</SelectItem>
            <SelectItem value="funcional">Funcional</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Dificuldade" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            <SelectItem value="iniciante">Iniciante</SelectItem>
            <SelectItem value="intermediario">Intermediário</SelectItem>
            <SelectItem value="avancado">Avançado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Workouts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockWorkouts.map((workout) => (
          <WorkoutCard key={workout.id} workout={workout} />
        ))}
      </div>
    </div>
  )
}
