import type React from "react"
import { TrainerNav } from "@/components/trainer-nav"

export default function TrainerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <TrainerNav />
      <main className="flex-1 p-8">{children}</main>
    </div>
  )
}
