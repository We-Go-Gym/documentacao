import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, Dumbbell, TrendingUp, Calendar, Plus } from "lucide-react"
import Link from "next/link"

// Mock data
const mockStats = {
  totalStudents: 24,
  activeStudents: 18,
  totalWorkouts: 45,
  workoutsThisWeek: 12,
}

const recentActivity = [
  {
    id: "1",
    type: "workout_completed",
    student: "João Silva",
    workout: "Treino de Peito e Tríceps",
    time: "2 horas atrás",
  },
  {
    id: "2",
    type: "new_student",
    student: "Maria Santos",
    time: "1 dia atrás",
  },
  {
    id: "3",
    type: "workout_assigned",
    student: "Pedro Costa",
    workout: "Cardio HIIT",
    time: "2 dias atrás",
  },
]

export default function TrainerDashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard do Treinador</h1>
        <p className="text-muted-foreground">Gerencie seus alunos e acompanhe o progresso de todos.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Alunos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalStudents}</div>
            <p className="text-xs text-muted-foreground">+3 este mês</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alunos Ativos</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.activeStudents}</div>
            <p className="text-xs text-muted-foreground">75% do total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Treinos Criados</CardTitle>
            <Dumbbell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalWorkouts}</div>
            <p className="text-xs text-muted-foreground">Na biblioteca</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Treinos esta semana</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.workoutsThisWeek}</div>
            <p className="text-xs text-muted-foreground">Atribuídos</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild>
              <Link href="/trainer/workouts/create">
                <Plus className="mr-2 h-4 w-4" />
                Criar Novo Treino
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/trainer/students">
                <Users className="mr-2 h-4 w-4" />
                Ver Todos os Alunos
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/trainer/workouts">
                <Dumbbell className="mr-2 h-4 w-4" />
                Biblioteca de Treinos
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Atividade Recente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  {activity.type === "workout_completed" && (
                    <p className="text-sm">
                      <span className="font-medium">{activity.student}</span> completou o treino{" "}
                      <span className="font-medium">{activity.workout}</span>
                    </p>
                  )}
                  {activity.type === "new_student" && (
                    <p className="text-sm">
                      <span className="font-medium">{activity.student}</span> se tornou seu aluno
                    </p>
                  )}
                  {activity.type === "workout_assigned" && (
                    <p className="text-sm">
                      Treino <span className="font-medium">{activity.workout}</span> atribuído para{" "}
                      <span className="font-medium">{activity.student}</span>
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                </div>
                <Badge variant="secondary">
                  {activity.type === "workout_completed" && "Concluído"}
                  {activity.type === "new_student" && "Novo Aluno"}
                  {activity.type === "workout_assigned" && "Atribuído"}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
