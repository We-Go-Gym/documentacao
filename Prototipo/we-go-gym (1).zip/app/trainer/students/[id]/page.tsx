import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Mail, Phone, ArrowLeft, Edit, Plus } from "lucide-react"
import Link from "next/link"

// Mock student detailed data
const mockStudent = {
  id: "1",
  name: "João Silva",
  email: "joao@email.com",
  phone: "(11) 99999-9999",
  joinDate: "15 de Janeiro, 2024",
  status: "Ativo",
  currentGoal: "Hipertrofia",
  workoutsCompleted: 28,
  totalWorkouts: 32,
  currentWeight: 75,
  targetWeight: 80,
  height: 175,
  age: 28,
  assignedWorkouts: [
    {
      id: "1",
      name: "Treino de Peito e Tríceps",
      assignedDate: "2024-01-20",
      completed: true,
      completedDate: "2024-01-22",
    },
    {
      id: "2",
      name: "Treino de Costas e Bíceps",
      assignedDate: "2024-01-22",
      completed: true,
      completedDate: "2024-01-24",
    },
    {
      id: "3",
      name: "Treino de Pernas",
      assignedDate: "2024-01-24",
      completed: false,
    },
  ],
  progressNotes: [
    {
      id: "1",
      date: "2024-01-20",
      note: "Aluno demonstrou boa forma nos exercícios de peito. Recomendo aumentar carga no supino.",
    },
    {
      id: "2",
      date: "2024-01-15",
      note: "Primeira avaliação realizada. Aluno tem bom condicionamento base.",
    },
  ],
}

export default function StudentDetailsPage({ params }: { params: { id: string } }) {
  const student = mockStudent

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const getStatusColor = (status: string) => {
    return status === "Ativo" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" asChild>
          <Link href="/trainer/students">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Link>
        </Button>
      </div>

      {/* Student Profile */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={student.avatar || "/placeholder.svg"} />
                <AvatarFallback className="text-lg">{getInitials(student.name)}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-2xl">{student.name}</CardTitle>
                <CardDescription className="text-base mt-1">Membro desde {student.joinDate}</CardDescription>
                <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Mail className="mr-1 h-4 w-4" />
                    {student.email}
                  </div>
                  <div className="flex items-center">
                    <Phone className="mr-1 h-4 w-4" />
                    {student.phone}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className={getStatusColor(student.status)}>{student.status}</Badge>
              <Button variant="outline" size="sm">
                <Edit className="mr-2 h-4 w-4" />
                Editar
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column - Stats and Info */}
        <div className="lg:col-span-1 space-y-6">
          {/* Physical Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Informações Físicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Idade:</span>
                <span className="font-medium">{student.age} anos</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Altura:</span>
                <span className="font-medium">{student.height} cm</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Peso atual:</span>
                <span className="font-medium">{student.currentWeight} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Meta de peso:</span>
                <span className="font-medium">{student.targetWeight} kg</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span className="text-muted-foreground">Objetivo:</span>
                <Badge variant="secondary">{student.currentGoal}</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Progress Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Progresso</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Treinos concluídos:</span>
                <span className="font-medium">{student.workoutsCompleted}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total de treinos:</span>
                <span className="font-medium">{student.totalWorkouts}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Taxa de conclusão:</span>
                <span className="font-medium">
                  {Math.round((student.workoutsCompleted / student.totalWorkouts) * 100)}%
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Workouts and Notes */}
        <div className="lg:col-span-2 space-y-6">
          {/* Assigned Workouts */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Treinos Atribuídos</CardTitle>
                <Button size="sm" asChild>
                  <Link href={`/trainer/students/${student.id}/assign-workout`}>
                    <Plus className="mr-2 h-4 w-4" />
                    Atribuir Treino
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.assignedWorkouts.map((workout) => (
                  <div key={workout.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{workout.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        Atribuído em {new Date(workout.assignedDate).toLocaleDateString("pt-BR")}
                      </p>
                      {workout.completed && workout.completedDate && (
                        <p className="text-sm text-green-600">
                          Concluído em {new Date(workout.completedDate).toLocaleDateString("pt-BR")}
                        </p>
                      )}
                    </div>
                    <Badge variant={workout.completed ? "default" : "secondary"}>
                      {workout.completed ? "Concluído" : "Pendente"}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Progress Notes */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Anotações de Progresso</CardTitle>
                <Button size="sm" variant="outline">
                  <Plus className="mr-2 h-4 w-4" />
                  Nova Anotação
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.progressNotes.map((note) => (
                  <div key={note.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">{new Date(note.date).toLocaleDateString("pt-BR")}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{note.note}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
