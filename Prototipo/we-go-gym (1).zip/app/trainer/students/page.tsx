import { StudentCard } from "@/components/student-card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Search, Plus } from "lucide-react"

// Mock students data
const mockStudents = [
  {
    id: "1",
    name: "João Silva",
    email: "joao@email.com",
    joinDate: "Jan 2024",
    workoutsCompleted: 28,
    currentGoal: "Hipertrofia",
    status: "Ativo" as const,
    lastWorkout: "2 dias atrás",
  },
  {
    id: "2",
    name: "Maria Santos",
    email: "maria@email.com",
    joinDate: "Fev 2024",
    workoutsCompleted: 15,
    currentGoal: "Perda de peso",
    status: "Ativo" as const,
    lastWorkout: "1 dia atrás",
  },
  {
    id: "3",
    name: "Pedro Costa",
    email: "pedro@email.com",
    joinDate: "Mar 2024",
    workoutsCompleted: 8,
    currentGoal: "Condicionamento",
    status: "Inativo" as const,
    lastWorkout: "1 semana atrás",
  },
  {
    id: "4",
    name: "Ana Oliveira",
    email: "ana@email.com",
    joinDate: "Jan 2024",
    workoutsCompleted: 32,
    currentGoal: "Força",
    status: "Ativo" as const,
    lastWorkout: "Hoje",
  },
  {
    id: "5",
    name: "Carlos Mendes",
    email: "carlos@email.com",
    joinDate: "Dez 2023",
    workoutsCompleted: 45,
    currentGoal: "Hipertrofia",
    status: "Ativo" as const,
    lastWorkout: "1 dia atrás",
  },
  {
    id: "6",
    name: "Lucia Ferreira",
    email: "lucia@email.com",
    joinDate: "Fev 2024",
    workoutsCompleted: 12,
    currentGoal: "Tonificação",
    status: "Ativo" as const,
    lastWorkout: "3 dias atrás",
  },
]

export default function StudentsPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Meus Alunos</h1>
          <p className="text-muted-foreground">Gerencie todos os seus alunos em um só lugar.</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Aluno
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input placeholder="Buscar alunos..." className="pl-10" />
        </div>
        <Select>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="ativo">Ativo</SelectItem>
            <SelectItem value="inativo">Inativo</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Objetivo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="hipertrofia">Hipertrofia</SelectItem>
            <SelectItem value="perda-peso">Perda de peso</SelectItem>
            <SelectItem value="forca">Força</SelectItem>
            <SelectItem value="condicionamento">Condicionamento</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockStudents.map((student) => (
          <StudentCard key={student.id} student={student} />
        ))}
      </div>
    </div>
  )
}
