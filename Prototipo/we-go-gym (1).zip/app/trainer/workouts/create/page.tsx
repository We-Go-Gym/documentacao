"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Plus, Trash2, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Exercise {
  id: string
  name: string
  sets: string
  reps: string
  rest: string
  description: string
  tips: string
}

export default function CreateWorkoutPage() {
  const [workoutData, setWorkoutData] = useState({
    name: "",
    description: "",
    category: "",
    difficulty: "",
    duration: "",
  })

  const [exercises, setExercises] = useState<Exercise[]>([
    {
      id: "1",
      name: "",
      sets: "",
      reps: "",
      rest: "",
      description: "",
      tips: "",
    },
  ])

  const addExercise = () => {
    const newExercise: Exercise = {
      id: Date.now().toString(),
      name: "",
      sets: "",
      reps: "",
      rest: "",
      description: "",
      tips: "",
    }
    setExercises([...exercises, newExercise])
  }

  const removeExercise = (id: string) => {
    setExercises(exercises.filter((exercise) => exercise.id !== id))
  }

  const updateExercise = (id: string, field: keyof Exercise, value: string) => {
    setExercises(exercises.map((exercise) => (exercise.id === id ? { ...exercise, [field]: value } : exercise)))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Workout created:", { workoutData, exercises })
    // Here you would typically save to your backend
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" asChild>
          <Link href="/trainer/workouts">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold mb-2">Criar Novo Treino</h1>
        <p className="text-muted-foreground">Crie um treino personalizado para seus alunos.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Workout Basic Info */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Básicas</CardTitle>
            <CardDescription>Defina as informações principais do treino.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome do Treino</Label>
                <Input
                  id="name"
                  placeholder="Ex: Treino de Peito e Tríceps"
                  value={workoutData.name}
                  onChange={(e) => setWorkoutData({ ...workoutData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Duração (minutos)</Label>
                <Input
                  id="duration"
                  type="number"
                  placeholder="60"
                  value={workoutData.duration}
                  onChange={(e) => setWorkoutData({ ...workoutData, duration: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                placeholder="Descreva o objetivo e foco deste treino..."
                value={workoutData.description}
                onChange={(e) => setWorkoutData({ ...workoutData, description: e.target.value })}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Categoria</Label>
                <Select
                  value={workoutData.category}
                  onValueChange={(value) => setWorkoutData({ ...workoutData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hipertrofia">Hipertrofia</SelectItem>
                    <SelectItem value="forca">Força</SelectItem>
                    <SelectItem value="cardio">Cardio</SelectItem>
                    <SelectItem value="funcional">Funcional</SelectItem>
                    <SelectItem value="resistencia">Resistência</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Dificuldade</Label>
                <Select
                  value={workoutData.difficulty}
                  onValueChange={(value) => setWorkoutData({ ...workoutData, difficulty: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a dificuldade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="iniciante">Iniciante</SelectItem>
                    <SelectItem value="intermediario">Intermediário</SelectItem>
                    <SelectItem value="avancado">Avançado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Exercises */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Exercícios</CardTitle>
                <CardDescription>Adicione os exercícios que compõem este treino.</CardDescription>
              </div>
              <Button type="button" onClick={addExercise} size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Adicionar Exercício
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {exercises.map((exercise, index) => (
              <div key={exercise.id} className="space-y-4 p-4 border rounded-lg">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Exercício {index + 1}</h4>
                  {exercises.length > 1 && (
                    <Button type="button" variant="outline" size="sm" onClick={() => removeExercise(exercise.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nome do Exercício</Label>
                    <Input
                      placeholder="Ex: Supino Reto"
                      value={exercise.name}
                      onChange={(e) => updateExercise(exercise.id, "name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-2">
                      <Label>Séries</Label>
                      <Input
                        placeholder="4"
                        value={exercise.sets}
                        onChange={(e) => updateExercise(exercise.id, "sets", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Repetições</Label>
                      <Input
                        placeholder="8-10"
                        value={exercise.reps}
                        onChange={(e) => updateExercise(exercise.id, "reps", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Descanso</Label>
                      <Input
                        placeholder="2 min"
                        value={exercise.rest}
                        onChange={(e) => updateExercise(exercise.id, "rest", e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Descrição do Exercício</Label>
                  <Textarea
                    placeholder="Descreva como executar o exercício..."
                    value={exercise.description}
                    onChange={(e) => updateExercise(exercise.id, "description", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Dicas de Execução</Label>
                  <Textarea
                    placeholder="Dicas importantes para a execução correta..."
                    value={exercise.tips}
                    onChange={(e) => updateExercise(exercise.id, "tips", e.target.value)}
                  />
                </div>

                {index < exercises.length - 1 && <Separator className="mt-4" />}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" asChild>
            <Link href="/trainer/workouts">Cancelar</Link>
          </Button>
          <Button type="submit">Criar Treino</Button>
        </div>
      </form>
    </div>
  )
}
