"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Calculator } from "lucide-react"

interface BMIResult {
  bmi: number
  category: string
  color: string
  description: string
}

export function BMICalculator() {
  const [height, setHeight] = useState("")
  const [weight, setWeight] = useState("")
  const [result, setResult] = useState<BMIResult | null>(null)

  const calculateBMI = () => {
    const heightInMeters = Number.parseFloat(height) / 100
    const weightInKg = Number.parseFloat(weight)

    if (heightInMeters > 0 && weightInKg > 0) {
      const bmi = weightInKg / (heightInMeters * heightInMeters)
      const roundedBMI = Math.round(bmi * 10) / 10

      let category = ""
      let color = ""
      let description = ""

      if (roundedBMI < 18.5) {
        category = "Abaixo do peso"
        color = "bg-blue-100 text-blue-800"
        description = "Você está abaixo do peso ideal. Considere consultar um nutricionista."
      } else if (roundedBMI >= 18.5 && roundedBMI < 25) {
        category = "Peso normal"
        color = "bg-green-100 text-green-800"
        description = "Parabéns! Você está dentro do peso ideal."
      } else if (roundedBMI >= 25 && roundedBMI < 30) {
        category = "Sobrepeso"
        color = "bg-yellow-100 text-yellow-800"
        description = "Você está com sobrepeso. Uma dieta equilibrada e exercícios podem ajudar."
      } else {
        category = "Obesidade"
        color = "bg-red-100 text-red-800"
        description = "Você está com obesidade. Recomendamos acompanhamento médico."
      }

      setResult({
        bmi: roundedBMI,
        category,
        color,
        description,
      })
    }
  }

  const resetCalculator = () => {
    setHeight("")
    setWeight("")
    setResult(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calculator className="mr-2 h-5 w-5" />
          Calculadora de IMC
        </CardTitle>
        <CardDescription>Calcule seu Índice de Massa Corporal e acompanhe sua evolução</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="height">Altura (cm)</Label>
            <Input
              id="height"
              type="number"
              placeholder="175"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="weight">Peso (kg)</Label>
            <Input
              id="weight"
              type="number"
              step="0.1"
              placeholder="70.5"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={calculateBMI} className="flex-1">
            Calcular IMC
          </Button>
          {result && (
            <Button variant="outline" onClick={resetCalculator}>
              Limpar
            </Button>
          )}
        </div>

        {result && (
          <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">{result.bmi}</div>
              <Badge className={result.color}>{result.category}</Badge>
            </div>
            <p className="text-sm text-muted-foreground text-center">{result.description}</p>

            {/* BMI Scale */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Escala de IMC:</h4>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Abaixo do peso</span>
                  <span className="text-muted-foreground">{"< 18.5"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Peso normal</span>
                  <span className="text-muted-foreground">18.5 - 24.9</span>
                </div>
                <div className="flex justify-between">
                  <span>Sobrepeso</span>
                  <span className="text-muted-foreground">25.0 - 29.9</span>
                </div>
                <div className="flex justify-between">
                  <span>Obesidade</span>
                  <span className="text-muted-foreground">{"≥ 30.0"}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
