"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts"

// Mock BMI progress data
const mockBMIData = [
  { date: "Jan", bmi: 24.6 },
  { date: "Fev", bmi: 24.5 },
  { date: "Mar", bmi: 24.3 },
  { date: "Abr", bmi: 24.1 },
  { date: "Mai", bmi: 24.2 },
  { date: "Jun", bmi: 24.0 },
  { date: "Jul", bmi: 23.9 },
  { date: "Ago", bmi: 23.8 },
]

export function BMIProgressChart() {
  const currentBMI = mockBMIData[mockBMIData.length - 1].bmi
  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { category: "Abaixo do peso", color: "text-blue-600" }
    if (bmi < 25) return { category: "Peso normal", color: "text-green-600" }
    if (bmi < 30) return { category: "Sobrepeso", color: "text-yellow-600" }
    return { category: "Obesidade", color: "text-red-600" }
  }

  const { category, color } = getBMICategory(currentBMI)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolução do IMC</CardTitle>
        <CardDescription>Acompanhe a evolução do seu Índice de Massa Corporal</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-6 p-4 bg-muted/30 rounded-lg">
          <div className="text-3xl font-bold">{currentBMI}</div>
          <div className={`text-sm font-medium ${color}`}>{category}</div>
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockBMIData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[18, 30]} />
              <Tooltip formatter={(value: number) => [`${value}`, "IMC"]} />

              {/* Reference lines for BMI categories */}
              <ReferenceLine y={18.5} stroke="#3b82f6" strokeDasharray="2 2" />
              <ReferenceLine y={25} stroke="#eab308" strokeDasharray="2 2" />
              <ReferenceLine y={30} stroke="#ef4444" strokeDasharray="2 2" />

              <Line
                type="monotone"
                dataKey="bmi"
                stroke="hsl(var(--accent))"
                strokeWidth={3}
                dot={{ fill: "hsl(var(--accent))", strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-4 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-3 h-0.5 bg-blue-500 mr-2"></div>
              <span>Abaixo do peso ({"< 18.5"})</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-3 h-0.5 bg-yellow-500 mr-2"></div>
              <span>Sobrepeso (25.0 - 29.9)</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-3 h-0.5 bg-red-500 mr-2"></div>
              <span>Obesidade ({"≥ 30.0"})</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
