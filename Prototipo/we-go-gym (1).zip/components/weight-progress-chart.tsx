"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

// Mock weight progress data
const mockWeightData = [
  { date: "Jan", weight: 75.2, bmi: 24.6 },
  { date: "Fev", weight: 74.8, bmi: 24.5 },
  { date: "Mar", weight: 74.1, bmi: 24.3 },
  { date: "Abr", weight: 73.5, bmi: 24.1 },
  { date: "Mai", weight: 73.8, bmi: 24.2 },
  { date: "Jun", weight: 73.2, bmi: 24.0 },
  { date: "Jul", weight: 72.9, bmi: 23.9 },
  { date: "Ago", weight: 72.5, bmi: 23.8 },
]

export function WeightProgressChart() {
  const currentWeight = mockWeightData[mockWeightData.length - 1].weight
  const previousWeight = mockWeightData[mockWeightData.length - 2].weight
  const weightChange = currentWeight - previousWeight
  const totalChange = currentWeight - mockWeightData[0].weight

  const getTrendIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="h-4 w-4 text-red-500" />
    if (change < 0) return <TrendingDown className="h-4 w-4 text-green-500" />
    return <Minus className="h-4 w-4 text-gray-500" />
  }

  const getTrendColor = (change: number) => {
    if (change > 0) return "text-red-500"
    if (change < 0) return "text-green-500"
    return "text-gray-500"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolução do Peso</CardTitle>
        <CardDescription>Acompanhe sua evolução de peso ao longo do tempo</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className="text-2xl font-bold">{currentWeight} kg</div>
            <div className="text-sm text-muted-foreground">Peso Atual</div>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className={`text-2xl font-bold flex items-center justify-center ${getTrendColor(weightChange)}`}>
              {getTrendIcon(weightChange)}
              <span className="ml-1">{Math.abs(weightChange).toFixed(1)} kg</span>
            </div>
            <div className="text-sm text-muted-foreground">Último Mês</div>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className={`text-2xl font-bold flex items-center justify-center ${getTrendColor(totalChange)}`}>
              {getTrendIcon(totalChange)}
              <span className="ml-1">{Math.abs(totalChange).toFixed(1)} kg</span>
            </div>
            <div className="text-sm text-muted-foreground">Total</div>
          </div>
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockWeightData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={["dataMin - 1", "dataMax + 1"]} />
              <Tooltip
                formatter={(value: number, name: string) => [
                  `${value} ${name === "weight" ? "kg" : ""}`,
                  name === "weight" ? "Peso" : "IMC",
                ]}
              />
              <Line
                type="monotone"
                dataKey="weight"
                stroke="hsl(var(--primary))"
                strokeWidth={3}
                dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
