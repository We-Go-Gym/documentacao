"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Plus, Scale } from "lucide-react"

interface WeightEntry {
  id: string
  weight: number
  date: string
  notes?: string
}

// Mock weight entries
const mockEntries: WeightEntry[] = [
  { id: "1", weight: 72.5, date: "2024-01-28", notes: "Após treino de pernas" },
  { id: "2", weight: 72.8, date: "2024-01-25", notes: "Manhã, em jejum" },
  { id: "3", weight: 73.2, date: "2024-01-22" },
  { id: "4", weight: 73.0, date: "2024-01-19", notes: "Fim de semana" },
]

export function WeightTracker() {
  const [entries, setEntries] = useState<WeightEntry[]>(mockEntries)
  const [newWeight, setNewWeight] = useState("")
  const [notes, setNotes] = useState("")

  const addWeightEntry = () => {
    if (newWeight) {
      const newEntry: WeightEntry = {
        id: Date.now().toString(),
        weight: Number.parseFloat(newWeight),
        date: new Date().toISOString().split("T")[0],
        notes: notes || undefined,
      }
      setEntries([newEntry, ...entries])
      setNewWeight("")
      setNotes("")
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getWeightChange = (currentWeight: number, previousWeight: number) => {
    const change = currentWeight - previousWeight
    if (change > 0) return { value: `+${change.toFixed(1)}`, color: "text-red-500" }
    if (change < 0) return { value: change.toFixed(1), color: "text-green-500" }
    return { value: "0.0", color: "text-gray-500" }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Scale className="mr-2 h-5 w-5" />
          Registro de Peso
        </CardTitle>
        <CardDescription>Registre seu peso regularmente para acompanhar sua evolução</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add new weight entry */}
        <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
          <h4 className="font-medium">Adicionar novo registro</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="newWeight">Peso (kg)</Label>
              <Input
                id="newWeight"
                type="number"
                step="0.1"
                placeholder="72.5"
                value={newWeight}
                onChange={(e) => setNewWeight(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Observações (opcional)</Label>
              <Input
                id="notes"
                placeholder="Ex: Manhã, em jejum"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <Button onClick={addWeightEntry} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                Adicionar
              </Button>
            </div>
          </div>
        </div>

        {/* Weight entries list */}
        <div className="space-y-3">
          <h4 className="font-medium">Histórico de peso</h4>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {entries.map((entry, index) => {
              const previousEntry = entries[index + 1]
              const change = previousEntry ? getWeightChange(entry.weight, previousEntry.weight) : null

              return (
                <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{entry.weight} kg</span>
                      {change && (
                        <Badge variant="outline" className={change.color}>
                          {change.value} kg
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(entry.date)}
                      {entry.notes && ` • ${entry.notes}`}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
